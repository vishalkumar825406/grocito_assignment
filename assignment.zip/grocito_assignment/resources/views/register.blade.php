<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Register</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

</head>

<body>
    <div class="container">
        <div class="row justify-content-center mt-5">
            <div class="col-8">
                <div class="card">
                    <div class="card-header bg-dark text-white">
                        <p>Add User</p>
                    </div>
                    <div class="card-body">
                        <form>
                            <div class="row">
                                <div class="col-6 mb-3">
                                    <label for="name" class="form-label">Name</label>
                                    <input type="text" class="form-control" id="name"
                                        aria-describedby="emailHelp">
                                </div>
                                <div class="col-6 mb-3">
                                    <label for="address" class="form-label">Email Address</label>
                                    <input type="email" class="form-control" id="name"
                                        aria-describedby="emailHelp">
                                </div>
                                <div class="col-6 mb-3">
                                    <label for="mobile" class="form-label">Phone</label>
                                    <input type="mobile" class="form-control" id="mobile"
                                        aria-describedby="emailHelp">
                                </div>

                                <div class="col-6 mb-3">
                                    <label for="state" class="form-label">Select State</label>
                                    <select name="state" id="state" >
                                        <option value="" disabled selected></option>
                                        @foreach ($states as $state)
                                        <option value="{{$state->id}}">{{$state->name}}</option>                                            
                                        @endforeach
                                    </select>
                                   
                                </div>
                                <div class="col-6 mb-3">
                                    <label for="city" class="form-label">Select City</label>
                                    <select name="city" id="city" >
                                        <option value="" disabled selected></option>
                                        @foreach ($cities as $city)
                                        <option value="{{$city->id}}">{{$city->name}}</option>                                            
                                        @endforeach
                                    </select>                                   
                                </div>

                                <div class="col-6 mb-3">
                                    <label for="pincode" class="form-label">Select Pincode</label>
                                    <select name="pincode" id="pincode" >
                                        <option value="" disabled selected></option>
                                        @foreach ($cities as $city)
                                        <option value="{{$city->id}}">{{$city->name}}</option>                                            
                                        @endforeach
                                    </select>
                                   
                                </div>
                               
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
