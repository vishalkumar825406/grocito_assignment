@extends('layouts.master')
@section('content')
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header mb-2 text-dark">Update  <a href="{{ route('user.index') }}" class="float-right">Back</a></div>
                    <div class="card-body">
                        @if ($errors->any())
                            <div class="alert alert-danger">
                                <ul>
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            </div>
                        @endif
                        <form method="POST" action="{{ route('user.update',['id'=>$user->id]) }}">
                            @csrf
                            <div class="row">
                                <div class="col-6 mb-3">
                                    <label for="name" class="form-label">Name</label>
                                    <input type="text" class="form-control" value="{{$user->name}}" name="name" id="name" aria-describedby="emailHelp">
                                </div>
                                <div class="col-6 mb-3">
                                    <label for="email" class="form-label">Email Address</label>
                                    <input type="email" class="form-control" value="{{$user->email}}" name="email" id="email" aria-describedby="emailHelp">
                                </div>
                                <div class="col-6 mb-3">
                                    <label for="mobile" class="form-label">Phone</label>
                                    <input type="mobile" class="form-control" value="{{$user->mobile}}" name="mobile" id="mobile" aria-describedby="emailHelp">
                                </div>
                                <div class="col-6 mb-3">
                                    <label for="state" class="form-label">Select State</label>
                                    <select name="state" id="state">
                                        <option value="" disabled selected>Select State</option>
                                        @foreach ($states as $state)
                                            <option value="{{ $state->id }}">{{ $state->name }}</option>

                                        @endforeach
                                    </select>
                                </div>

                                <div class="col-6 mb-3">
                                    <label for="city" class="form-label">Select City</label>
                                    <select name="city" id="city" disabled>
                                        <option value="" disabled selected>Select City</option>
                                    </select>
                                </div>

                                <div class="col-6 mb-3">
                                    <label for="pincode" class="form-label">Pincode</label>
                                    <select name="pincode" id="pincode" disabled>
                                        <option value="" disabled selected>Select Pincode</option>
                                    </select>
                                </div>

                               
                               

                               
                                <div class="col-12">
                                    <button type="submit" class="btn btn-primary float-right">Submit</button>
                                </div>

                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    

    @endsection
