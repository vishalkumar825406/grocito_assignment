<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Login</title>
</head>

<body>
    <div class="container">
        <div class="row  mt-5 justify-content-center align-items-center">
            <div class="col-6  mt-5">
                <div class="card  mt-5">
                    <form action="{{ route('otp.generate') }}" method="post">
                        @csrf
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12 text-center">
                                    <span class="info-text">Please enter your mobile number to signup or
                                        login</span><br>
                                    <div class="position-relative mt-3 form-input">
                                        <input class="form-control" id="mobile" name="mobile">
                                    </div>
                                    {{-- <input type="text"> --}}
                                </div>
                                <div class="col-12 text-center mt-3" id="enterOtp" style="display: none">
                                    <span class="info-text">Please enter OTP</span><br>
                                    <div class="position-relative mt-3 form-input">
                                        <input class="form-control" id="otp" name="otp">
                                    </div>
                                </div>
                                <div class="col-12 mt-3 ">
                                    <button type="submit" id="generateOTPButton" class="btn btn-primary"
                                        name="submit">Send OTP</button>
                                    
                                </div>
                            </div>
                        </div>
                    </form>
                    <form>
                        @csrf
                        <button type="button" id="verifyOTPButton" class="btn btn-primary"
                            name="submit" style="display: none;">Verify OTP</button>
                    </form>
                </div>
            </div>
        </div>

    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"
        integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script>
        $(document).ready(function() {
            $('#generateOTPButton').click(function(e) {
                e.preventDefault();
                var phoneNumber = $('#mobile').val();
                $.ajax({
                    url: "{{ route('otp.generate') }}",
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    data: {
                        mobile: phoneNumber
                    },
                    success: function(response) {
                        console.log(response);
                        $('#generateOTPButton').hide();
                        $('#verifyOTPButton').show();
                        $('#enterOtp').show();
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                    }
                });
            });


            $('#verifyOTPButton').click(function(e) {
                e.preventDefault();
                var phoneNumber = $('#mobile').val();
                var otp = $('#otp').val();
              
                $.ajax({
                    url: "{{ route('otp.verify') }}",
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    data: {
                        mobile: phoneNumber,
                        otp: otp
                    },
                    success: function(response) {
                       if(response == 1){
                        window.location.href = "{{route('admin.dashboard')}}";
                       } else if(response == 2){
                        window.location.href = "{{route('dashboard')}}";
                       }
                    },
                    error: function(error) {
                        alert(error.responseJSON.error);
                        // alert('hello');
                    }

                });
            });

        });
    </script>


</body>

</html>
