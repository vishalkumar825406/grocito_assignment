@extends('layouts.master')
@section('content')
<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-md-2"></div>
        <div class="col-10 col-md-10 mt-2">
            <div class="card  ">
                <div class="card-header bg-dark text-white">
                    Pincode <a href="{{ route('pincode.create') }}" class="float-right text-white">Add Pincode</a>
                </div>
                <div class="card-body px-4 py-2">
                    <table id="myTable" class="display">
                        <thead>
                            <tr>
                                <th>S.no</th>                               
                                <th>Pincode</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($pincodes as $pincode)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>{{ $pincode->pincode }}</td>
                                   
                                    <td>
                                        @if ($pincode->status == 1)
                                            <a href="" class="btn btn-success">Approved</a>
                                        @elseif($pincode->status == 0)
                                            <a href="" class="btn btn-danger">Rejected</a>   
                                            @endif                                    
                                    </td>
                                    <td style="text-align: center; vertical-align: middle; margin-top: 10px;">
                                        <div class="d-flex" style="gap: 2px;">

                                            <a href="{{ route('pincode.edit', ['id' => $pincode->id]) }}"
                                                class="btn btn-primary">Edit</a>
                                            <form method="POST"
                                                action="{{ route('pincode.delete', ['id' => $pincode->id]) }}">
                                                @csrf
                                                @method('POST')
                                                <button class="btn btn-danger"
                                                    onclick="return confirm('Are you sure you want to delete this Pincode?')">Delete</button>
                                            </form>
                                           
                                        </div>

                                    </td>
                                </tr>
                            @endforeach


                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
</div>


@endsection