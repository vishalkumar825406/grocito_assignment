@extends('layouts.master')
@section('content')

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header mb-2">Edit State</div>
                    <div class="card-body">
                        <form method="POST" action="{{ route('state.update',['id'=>$state->id]) }}">
                            @csrf
                            <div class="row mb-3">
                                <label for="state"
                                    class="col-md-4 col-form-label text-md-end">&nbsp;&nbsp;&nbsp;&nbsp;State Name</label>

                                <div class="col-md-6">
                                    <input id="state" type="text"
                                        class="form-control @error('state') is-invalid @enderror" name="state"
                                        autocomplete="state" autofocus value="{{ $state->state_name }}">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="status"
                                    class="col-md-4 col-form-label text-md-end">&nbsp;&nbsp;&nbsp;&nbsp;Status</label>

                                <div class="col-md-6">
                                    <input id="status" type="text"
                                        class="form-control @error('status') is-invalid @enderror"
                                        value="{{ $state->status }}" name="status" autocomplete="status" autofocus>

                                </div>
                            </div>

                            <div class="row mb-2">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        Submit
                                    </button>&nbsp;&nbsp;&nbsp;&nbsp;
                                    <a href="{{ route('admin.dashboard') }}" class="btn btn-danger">cancel</a>
                                </div>
                                <div class="col-md-6 offset-md-4">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection