@extends('layouts.master')
@section('content')

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header mb-2">Edit City</div>
                    <div class="card-body">
                        <form method="POST" action="{{ route('city.update',['id'=>$city->id]) }}">

                            @csrf
                            <div class="row mb-3">
                                <label for="state" class="col-md-4 col-form-label text-md-end">State</label>

                                <div class="col-md-6">
                                    <select name="state" class="form-select" aria-label="Default select example"
                                        id="state">
                                        <option selected>Select State </option>

                                        @foreach ($states as $state)
                                            {{-- <option value="{{ $state->id }}">{{ $state->name }}</option> --}}
                                            <option value="{{ $state->id }}"  @if ($state->id == $city->state_id) selected @endif>{{ $state->name }}</option>

                                        @endforeach
                                    </select>


                                </div>
                            </div>

                            <div class="row mb-3">
                                <label for="name"
                                    class="col-md-4 col-form-label text-md-end">&nbsp;&nbsp;&nbsp;&nbsp;City
                                    Name</label>

                                <div class="col-md-6">
                                    <input id="city" type="text" value="{{$city->name}}"
                                        class="form-control @error('city') is-invalid @enderror" name="city"
                                        autocomplete="city" autofocus>

                                </div>
                            </div>


                            <div class="row mb-2">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        Submit
                                    </button>&nbsp;&nbsp;&nbsp;&nbsp;
                                    <a href="{{ route('admin.dashboard') }}" class="btn btn-danger">cancel</a>
                                </div>
                                <div class="col-md-6 offset-md-4">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection