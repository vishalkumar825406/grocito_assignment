<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\City;


class CityController extends Controller
{
    public function index(){
        $cities = City::with('state')->get();
        return view('city.index', compact('cities'));
    }
    public function create()
    {
        $data = DB::table('states')->get();
        return view('city.create', compact('data'));
    }
    public function store(Request $request)
    {
        $request->validate([
            'state' => 'required|numeric',
            'city' => 'required|string',
        ]);

        $city = new City();
        $city->state_id = $request->input('state');
        $city->name = $request->input('city');
        $city->save();

        return redirect()->route('admin.dashboard')->with('success', 'City added successfully!');

    }
     public function delete(Request $request,$id){
        $city = City::find($id);
        $city->update(['status' => 0]);
        return redirect()->back()->with('success', 'User Deactivated successfully!');
     }

     public function edit($id)
     {
        
        $states = DB::table('states')->get();
         $city = DB::table('cities')->where('id', $id)->first();         
         
 
         return view('city.edit', compact('states', 'city'));
     }
     
 
     public function update(Request $request, $id)
     {
         $request->validate([
             'state' => 'required|numeric',
             'city' => 'required|string|unique:cities,name,' . $id . ',id',             
         ]);
 
        $city = City::find($id);

         if (!$city) {
             return redirect()->route('admin.dashboard')->with('error', 'City not found!');
         }
         $city->state_id = $request->input('state');
         $city->name = $request->input('city');
         $city->save();
 
         return redirect()->route('admin.dashboard')->with('success', 'City updated successfully!');
     }

     public function getCities($stateId)
{
    $cities = City::where('state_id', $stateId)->get();
    return $cities;
}
}
