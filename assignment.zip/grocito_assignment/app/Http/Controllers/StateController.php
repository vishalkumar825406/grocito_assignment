<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\State;
use Illuminate\Support\Facades\DB;


class StateController extends Controller
{
    public function create(){
        return view('state.crete');
    }

    public function store(Request $request){        
       
            $request->validate([
                'state' => 'required|string|max:255', 
            ]);
    
            $state = new State();
            $state->name = $request->input('state');
    
            $state->save();
            return redirect()->route('state.index')->with('success', 'State added successfully');
        }
    
    public function edit($id){
        $state = State::where('id', $id)->first();
        return view('state.edit', compact('state'));        
    }
    public function update(Request $request,$id){
        $request->validate([
            'state' => 'required|string',
            'status' => 'required|numeric',
        ]);

        $state = State::find($id);
        if (!$state) {
            return redirect()->route('admin.dashboard')->with('error', 'City not found!');
        }
        $state->name = $request->input('state');
        $state->status = $request->input('status');
        $state->save();

        return redirect()->route('state.index')->with('success', 'City updated successfully!');
    
        
    }

    public function index()
    {
        $states = DB::table('states')->get();
        return view('state.index', compact('states'));
    }

    public function delete(Request $request,$id){
        $state = State::find($id);
        $state->update(['status' => 0]);
        return redirect()->back()->with('success', 'User Deactivated successfully!');

    }
}
