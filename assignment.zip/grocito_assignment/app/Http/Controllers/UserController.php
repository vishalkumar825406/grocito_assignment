<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
    public function index()
    {
        $users = User::all();
        return view('user.index', compact('users'));
    }
    public function create()
    {
        $states = DB::table('states')->get();
        return view('user.create', compact('states'));
    }
    public function store(Request $request)
    {
        $request = $request->validate([
            'name' => 'required|string',
            'email' => 'required|email',
            'mobile' => 'required|string',
            'state' => 'required|exists:states,id',
            'city' => 'required|exists:cities,id',
            'pincode' => 'required|exists:pincodes,id',
        ]);

        $user = new User();
        $user->name = $request['name'];
        $user->email = $request['email'];
        $user->mobile = $request['mobile'];
        $user->state_id = $request['state'];
        $user->city_id = $request['city'];
        $user->pincode = $request['pincode'];

        $user->save();

        return redirect()->route('user.index')->with('success', 'Form submitted successfully!');
    }

    public function edit(Request $request, $id)
    {
        $states = DB::table('states')->get();
        $user = DB::table('users')->where('id', $id)->first();
        return view('user.edit', compact('states', 'user'));
    }

    public function update(Request $request, $id)
    {
        $request = $request->validate([
            'name' => 'required|string',
            'email' => 'required|email',
            'mobile' => 'required|string',
            'state' => 'required|exists:states,id',
            'city' => 'required|exists:cities,id',
            'pincode' => 'required|exists:pincodes,id',
        ]);

        $user = User::findOrFail($id);

        $user->name = $request['name'];
        $user->email = $request['email'];
        $user->mobile = $request['mobile'];
        $user->state_id = $request['state'];
        $user->city_id = $request['city'];
        $user->pincode = $request['pincode'];

        $user->save();

        return redirect()->route('user.index')->with('success', 'User updated successfully!');
    }

    public function delete(Request $request,$id){
        $user = User::find($id);
        $user->update(['status' => 0]);
        return redirect()->back()->with('success', 'User Deactivated successfully!');
     }

}
