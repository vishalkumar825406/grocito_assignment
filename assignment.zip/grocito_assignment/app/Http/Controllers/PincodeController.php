<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pincode;
use Illuminate\Support\Facades\DB;


class PincodeController extends Controller
{
    
    public function create(){
        $states = DB::table('states')->get();
        return view('pincode.create',compact('states'));

    }

    public function store(Request $request)
    {
        $request = $request->validate([
            'state' => 'required|exists:states,id',
            'city' => 'required|exists:cities,id',
            'pincode' => 'required|string|max:255|unique:pincodes,pincode',
        ]);

        $pincode = new Pincode();
        $pincode->state_id = $request['state'];
        $pincode->city_id = $request['city'];
        $pincode->pincode = $request['pincode'];

        $pincode->save();

        return redirect()->route('pincode.index')->with('success', 'Pincode added successfully!');
    }

    public function index(){
        $pincodes = Pincode::all();
        return view('pincode.index',compact('pincodes'));
    }
    public function edit(Request $request, $id){
        $pincode = Pincode::find($id);
        $states = DB::table('states')->get();
        return view('pincode.edit',compact('pincode','states'));        
    }
    public function update(Request $request, $id)
    {
        $request = $request->validate([
            'state' => 'required|exists:states,id',
            'city' => 'required|exists:cities,id',
            'pincode' => 'required|string|max:255|unique:pincodes,pincode,'.$id,
        ]);

        $pincode = Pincode::findOrFail($id);

        $pincode->state_id = $request['state'];
        $pincode->city_id = $request['city'];
        $pincode->pincode = $request['pincode'];

        $pincode->save();

        return redirect()->route('pincode.index')->with('success', 'Pincode updated successfully!');
    }


    public function delete(Request $request,$id){
        $pincode = Pincode::find($id);
        $pincode->update(['status' => 0]);
        return redirect()->back()->with('success', 'Pincode Deactivated successfully!');
     }

    public function getPincodes($cityId)
    {
        $pincodes = Pincode::where('city_id', $cityId)->get();
        return response()->json($pincodes);
    }
}
