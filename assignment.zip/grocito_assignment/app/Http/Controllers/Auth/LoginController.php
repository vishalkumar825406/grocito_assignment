<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

class LoginController extends Controller
{
    public function login(){
        return view('login');
    }
    public function register(){
        return view('register');
    }
    public function generateOTP(Request $request)
    {
        $phoneNumber = $request->input('mobile');
        $otp = rand(1000, 9999);
        $expiryTime = now()->addMinutes(15);

        $user = User::where('mobile', $phoneNumber)->first();
        if (!$user) {
            $user = new User();
            $user->mobile = $phoneNumber;
        }
        $user->otp = $otp;
        $user->otp_expiry = $expiryTime;
        $user->save();

        return response()->json(['otp' => $otp]);
    }

    // public function verifyOTP(Request $request)
    // {
    //     // return 1;
    //     $phoneNumber = $request->input('mobile');
    //     $otp = $request->input('otp');

    //     $user = User::where('mobile', $phoneNumber)->first();
    //     return $user;

    //     if ($user && now()->lt($user->otp_expiry) && $otp == $user->otp) {
    //         Auth::login($user);

    //         return redirect()->route('dashboard')->with('success', 'OTP Verified Successfully!!');
    //     }
    //     return back()->withErrors(['otp' => 'Invalid OTP']);

    // }
    public function verifyOTP(Request $request)
    {
        // Validate request input
        $request->validate([
            'mobile' => 'required|string',
            'otp' => 'required|string',
        ]);
    
        // Retrieve input values
        $phoneNumber = $request->input('mobile');
        $otp = $request->input('otp');
    
        $user = User::where('mobile', $phoneNumber)->first();
    
        if ($user && now()->lt($user->otp_expiry) && $otp === $user->otp) {
            Auth::login($user); 
            if($user->role == 1){
            return 1;
            }
            return 2;
        }
    
        return response()->json(['error' => 'Invalid OTP or Mobile Number'], 400);
    }
    
    public function dashboard()
    {
        // return 1;
        return view('dashboard');
    }
    public function adminDashboard(){
        return view('admin_dashboard');
    }

    public function logout()
    {
        Auth::logout();
        return redirect('/login');
    }
}
