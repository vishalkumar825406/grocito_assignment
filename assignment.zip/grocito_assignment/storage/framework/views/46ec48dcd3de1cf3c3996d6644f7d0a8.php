
<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header mb-2 text-dark">Update  <a href="<?php echo e(route('user.index')); ?>" class="float-right">Back</a></div>
                    <div class="card-body">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <form method="POST" action="<?php echo e(route('user.update',['id'=>$user->id])); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-6 mb-3">
                                    <label for="name" class="form-label">Name</label>
                                    <input type="text" class="form-control" value="<?php echo e($user->name); ?>" name="name" id="name" aria-describedby="emailHelp">
                                </div>
                                <div class="col-6 mb-3">
                                    <label for="email" class="form-label">Email Address</label>
                                    <input type="email" class="form-control" value="<?php echo e($user->email); ?>" name="email" id="email" aria-describedby="emailHelp">
                                </div>
                                <div class="col-6 mb-3">
                                    <label for="mobile" class="form-label">Phone</label>
                                    <input type="mobile" class="form-control" value="<?php echo e($user->mobile); ?>" name="mobile" id="mobile" aria-describedby="emailHelp">
                                </div>
                                <div class="col-6 mb-3">
                                    <label for="state" class="form-label">Select State</label>
                                    <select name="state" id="state">
                                        <option value="" disabled selected>Select State</option>
                                        <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($state->id); ?>"><?php echo e($state->name); ?></option>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="col-6 mb-3">
                                    <label for="city" class="form-label">Select City</label>
                                    <select name="city" id="city" disabled>
                                        <option value="" disabled selected>Select City</option>
                                    </select>
                                </div>

                                <div class="col-6 mb-3">
                                    <label for="pincode" class="form-label">Pincode</label>
                                    <select name="pincode" id="pincode" disabled>
                                        <option value="" disabled selected>Select Pincode</option>
                                    </select>
                                </div>

                               
                               

                               
                                <div class="col-12">
                                    <button type="submit" class="btn btn-primary float-right">Submit</button>
                                </div>

                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\grocito_assignment\resources\views/user/edit.blade.php ENDPATH**/ ?>