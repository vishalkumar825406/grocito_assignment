
<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-md-2"></div>
        <div class="col-10 col-md-10 mt-2">
            <div class="card  ">
                <div class="card-header bg-dark text-white">
                    City <a href="<?php echo e(route('state.create')); ?>" class="float-right text-white">Add City</a>
                </div>
                <div class="card-body px-4 py-2">
                    <table id="myTable" class="display">
                        <thead>
                            <tr>
                                <th>S.no</th>                               
                                <th>State Name</th>
                                <th>City Name</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($city->state->name); ?></td>
                                    <td><?php echo e($city->name); ?></td>
                                   
                                    <td>
                                        <?php if($city->status == 1): ?>
                                            <a href="" class="btn btn-success">Approved</a>
                                        <?php elseif($city->status == 0): ?>
                                            <a href="" class="btn btn-danger">Rejected</a>   
                                            <?php endif; ?>                                    
                                    </td>
                                    <td style="text-align: center; vertical-align: middle; margin-top: 10px;">
                                        <div class="d-flex" style="gap: 2px;">

                                            <a href="<?php echo e(route('city.edit', ['id' => $city->id])); ?>"
                                                class="btn btn-primary">Edit</a>
                                            <form method="POST"
                                                action="<?php echo e(route('city.delete', ['id' => $city->id])); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('POST'); ?>
                                                <button class="btn btn-danger"
                                                    onclick="return confirm('Are you sure you want to delete this City?')">Delete</button>
                                            </form>
                                           
                                        </div>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\grocito_assignment\resources\views/city/index.blade.php ENDPATH**/ ?>