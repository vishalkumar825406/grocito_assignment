<nav class="navbar navbar-expand-md navbar-dark bg-dark shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(route('admin.dashboard')); ?>">Task
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <!-- Left Side Of Navbar -->
            <ul class="navbar-nav ms-auto">


            </ul>


            <ul class="navbar-nav ml-auto">

                <li class="nav-item dropdown">
                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                        data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                        <?php echo e(Auth::user()->mobile); ?>

                    </a>

                    
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        
                        <a class="dropdown-item" href="<?php echo e(route('user.index')); ?>">
                            <?php echo e(__('Manage User')); ?>

                        </a>
                        <a class="dropdown-item" href="<?php echo e(route('state.index')); ?>">
                            <?php echo e(__('Manage State')); ?>

                        </a>
                        <a class="dropdown-item" href="<?php echo e(route('city.index')); ?>">
                            <?php echo e(__('Manage City')); ?>

                        </a>
                        <a class="dropdown-item" href="<?php echo e(route('pincode.index')); ?>">
                            <?php echo e(__('Manage Pincode')); ?>

                        </a>
                        
                       
                    
                        <a class="dropdown-item text-dark" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            <?php echo e(__('Logout')); ?>

                        </a>
                    
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                    
                </li>

            </ul>
        </div>
    </div>
</nav>
<?php /**PATH D:\xampp\htdocs\grocito_assignment\resources\views/layouts/header.blade.php ENDPATH**/ ?>