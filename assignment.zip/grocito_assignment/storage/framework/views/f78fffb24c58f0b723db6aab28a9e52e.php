
<?php $__env->startSection('content'); ?>
<h4>Use Dropdown Section, If you want to manage Modules</h4>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\grocito_assignment\resources\views/admin_dashboard.blade.php ENDPATH**/ ?>