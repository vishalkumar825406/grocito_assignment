<?php
    if (Auth::check()) {
    // Get the ID of the currently authenticated user
    $userId = Auth::id();

    // Now you can use $userId for your purposes
    echo "User ID: $userId";
} else {
    // User is not logged in
    echo "User is not logged in.";
}
?><?php /**PATH D:\xampp\htdocs\grocito_assignment\resources\views/welcome.blade.php ENDPATH**/ ?>