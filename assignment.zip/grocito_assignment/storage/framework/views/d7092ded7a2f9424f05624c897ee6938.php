<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

     
     <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.23/css/jquery.dataTables.css">



</head>
<style>
    select {
        width: 100%;
        height: 35px;
        border: 1px solid #ddd6d6;
        border-radius: 5px;
    }
        </style>
<body>
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="py-4">
        <?php echo $__env->yieldContent('content'); ?>
    </main>



<script type="text/javascript" charset="utf8" src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.23/js/jquery.dataTables.js"></script>

<script>
    $(document).ready(function() {
        $('#myTable').DataTable();

        $('#state').change(function() {
                    var stateId = $(this).val();
                    if (stateId) {
                        $.ajax({
                            type: "GET",
                            url: "<?php echo e(route('city.get', ['stateId' => ':stateId'])); ?>".replace(
                                ':stateId', stateId),
                            success: function(res) {
                                if (res) {
                                    $("#city").empty();
                                    $("#city").append(
                                        '<option value="" selected>Select City</option>');
                                    $.each(res, function(key, value) {
                                        $("#city").append('<option value="' + value.id +
                                            '">' + value.name + '</option>');
                                    });
                                    $("#city").prop('disabled', false);
                                } else {
                                    $("#city").empty();
                                }
                            }
                        });
                    } else {
                        $("#city").empty();
                    }
                });

                // for pincode
                $('#city').change(function() {
                    var cityId = $(this).val();
                    if (cityId) {
                        $.ajax({
                            type: "GET",
                            url: "<?php echo e(route('pincode.get', ['cityId' => ':cityId'])); ?>".replace(
                                ':cityId', cityId),
                            success: function(res) {
                                if (res) {
                                    $("#pincode").empty();
                                    $("#pincode").append(
                                        '<option value="" selected>Select Pincode</option>');
                                    $.each(res, function(key, value) {
                                        $("#pincode").append('<option value="' + value.id +
                                            '">' + value.pincode + '</option>');
                                    });
                                    $("#pincode").prop('disabled', false);
                                } else {
                                    $("#pincode").empty();
                                }
                            }
                        });
                    } else {
                        $("#pincode").empty();
                    }
                });
    });
</script>

</body>
</html><?php /**PATH D:\xampp\htdocs\grocito_assignment\resources\views/layouts/master.blade.php ENDPATH**/ ?>