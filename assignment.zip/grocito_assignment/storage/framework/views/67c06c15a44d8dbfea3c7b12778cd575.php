
<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-md-2"></div>
        <div class="col-10 col-md-10 mt-2">
            <div class="card  ">
                <div class="card-header bg-dark text-white">
                    City <a href="<?php echo e(route('user.create')); ?>" class="float-right text-white">Add User</a>
                </div>
                <div class="card-body px-4 py-2">
                    <table id="myTable" class="display">
                        <thead>
                            <tr>
                                <th>S.no</th>                               
                                <th>Mobile Number</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($user->mobile); ?></td>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                   
                                    <td>
                                        <?php if($user->status == 1): ?>
                                            <a href="" class="btn btn-success">Approved</a>
                                        <?php elseif($user->status == 0): ?>
                                            <a href="" class="btn btn-danger">Rejected</a>   
                                            <?php endif; ?>                                    
                                    </td>
                                    <td style="text-align: center; vertical-align: middle; margin-top: 10px;">
                                        <div class="d-flex" style="gap: 2px;">

                                            <a href="<?php echo e(route('user.edit', ['id' => $user->id])); ?>"
                                                class="btn btn-primary">Edit</a>
                                            <form method="POST"
                                                action="<?php echo e(route('user.delete', ['id' => $user->id])); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('POST'); ?>
                                                <button class="btn btn-danger"
                                                    onclick="return confirm('Are you sure you want to delete this User?')">Delete</button>
                                            </form>
                                           
                                        </div>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\grocito_assignment\resources\views/user/index.blade.php ENDPATH**/ ?>