<?php

use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\CityController;
use App\Http\Controllers\PincodeController;
use App\Http\Controllers\StateController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
 */

Route::get('/', function () {
    return view('login');
});
Route::get('/login', [LoginController::class, 'login'])->name('login');
Route::post('/logout', [LoginController::class, 'logout'])->name('logout');
Route::post('/generate-otp', [LoginController::class, 'generateOTP'])->name('otp.generate');
Route::post('/verify-otp', [LoginController::class, 'verifyOTP'])->name('otp.verify');

Route::middleware(['auth'])->group(function () {
    // Route::get('/dashboard', [LoginController::class, 'dashboard'])->name('dashboard');
    Route::get('/dashboard', [LoginController::class, 'dashboard'])->name('dashboard');

});

Route::middleware(['admin'])->prefix('admin')->group(function () {
    Route::get('/dashboard', [LoginController::class, 'adminDashboard'])->name('admin.dashboard');
    //state routes
    Route::get('/state', [StateController::class, 'index'])->name('state.index');
    Route::get('/add/state', [StateController::class, 'create'])->name('state.create');
    Route::post('/add/state', [StateController::class, 'store'])->name('state.store');
    Route::get('/edit/state/{id}', [StateController::class, 'edit'])->name('state.edit');
    Route::post('/edit/state/{id}', [StateController::class, 'update'])->name('state.update');
    Route::post('/state/delete/{id}', [StateController::class, 'delete'])->name('state.delete');

    // city routes
    Route::get('/city', [CityController::class, 'index'])->name('city.index');
    Route::get('/add/city', [CityController::class, 'create'])->name('city.create');
    Route::post('/add/city', [CityController::class, 'store'])->name('city.store');
    Route::get('/edit/city/{id}', [CityController::class, 'edit'])->name('city.edit');
    Route::post('/edit/city/{id}', [CityController::class, 'update'])->name('city.update');
    Route::post('/city/delete/{id}', [CityController::class, 'delete'])->name('city.delete');
    Route::get('/get-cities/{stateId}', [CityController::class, 'getCities'])->name('city.get');

// pincode routes
    Route::get('/pincode', [PincodeController::class, 'index'])->name('pincode.index');
    Route::get('/pincode/add', [PincodeController::class, 'create'])->name('pincode.create');
    Route::post('/pincode/add', [PincodeController::class, 'store'])->name('pincode.store');
    Route::post('/pincode/update/{id}', [PincodeController::class, 'update'])->name('pincode.update');
    Route::post('/pincode/delete/{id}', [PincodeController::class, 'delete'])->name('pincode.delete');
    Route::get('/pincode/edit/{id}', [PincodeController::class, 'edit'])->name('pincode.edit');


    Route::get('/get-pincodes/{cityId}', [PincodeController::class, 'getPincodes'])->name('pincode.get');

    // user routes
    Route::get('/user', [UserController::class, 'index'])->name('user.index');
    Route::get('/user/add', [UserController::class, 'create'])->name('user.create');
    Route::post('/user/add', [UserController::class, 'store'])->name('user.store');
    Route::get('/edit/user/{id}', [UserController::class, 'edit'])->name('user.edit');
    Route::post('/edit/user/{id}', [UserController::class, 'update'])->name('user.update');
    Route::post('/user/delete/{id}', [UserController::class, 'delete'])->name('user.delete');

});
